import os

mapniklibpath = '/usr/local/lib/mapnik'
inputpluginspath = '/usr/local/lib/mapnik/input'
fontscollectionpath = '/usr/local/lib/mapnik/fonts'
localpath = os.path.dirname(os.path.abspath( __file__ ))
mapniklibpath = os.path.join(localpath, 'mapnik.libs')
mapniklibpath = os.path.normpath(mapniklibpath)
inputpluginspath = os.path.join(localpath, 'input')
fontscollectionpath = os.path.join(localpath, 'fonts')
__all__ = [mapniklibpath,inputpluginspath,fontscollectionpath]

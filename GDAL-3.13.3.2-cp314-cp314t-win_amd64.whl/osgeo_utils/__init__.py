"""""" # start delvewheel patch
def _delvewheel_patch_1_13_2():
    import os
    if os.path.isdir(libs_dir := os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir, 'gdal.libs'))):
        os.add_dll_directory(libs_dir)


_delvewheel_patch_1_13_2()
del _delvewheel_patch_1_13_2
# end delvewheel patch

__package_name__ = "gdal-utils"
gdal_utils_version = (3, 13, 3, 0)
__version__ = ".".join(str(i) for i in gdal_utils_version)
__author__ = "Frank Warmerdam"
__author_email__ = "warmerdam@pobox.com"
__maintainer__ = "Idan Miara"
__maintainer_email__ = "idan@miara.com"
__description__ = (
    "gdal-utils: An extension library for GDAL - Geospatial Data Abstraction Library"
)
__license_type__ = "MIT"
__url__ = "http://www.gdal.org"

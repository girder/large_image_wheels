# __init__ for osgeo package.


# start delvewheel patch
def _delvewheel_patch_1_13_2():
    import os
    if os.path.isdir(libs_dir := os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir, 'gdal.libs'))):
        os.add_dll_directory(libs_dir)


_delvewheel_patch_1_13_2()
del _delvewheel_patch_1_13_2
# end delvewheel patch

import os
import re

_localpath = os.path.dirname(os.path.abspath(__file__))
# HDF5 and netCDF read HDF5_PLUGIN_PATH when they initialize, so it is set
# before the libraries load.  The bundled filter plugins are appended, so a
# path the user set is searched first.
_pluginpath = os.path.join(_localpath, "hdf5plugin")
if _pluginpath not in os.environ.get("HDF5_PLUGIN_PATH", "").split(os.pathsep):
    os.environ["HDF5_PLUGIN_PATH"] = os.pathsep.join([p for p in (os.environ.get("HDF5_PLUGIN_PATH"), _pluginpath) if p])
from . import osr
from . import gdal

# HDF5 loads a plugin with LoadLibraryEx(LOAD_WITH_ALTERED_SEARCH_PATH),
# which does not search the add_dll_directory list delvewheel puts
# gdal.libs on, so a plugin import that is not loaded yet (bz2) would not
# resolve.  ctypes does search that list: load the plugins here, and
# HDF5's later load of the same files gets these modules.
import ctypes
_hdf5plugins = []
for _name in (os.listdir(_pluginpath) if os.path.isdir(_pluginpath) else []):
    if _name.lower().endswith(".dll"):
        try:
            _hdf5plugins.append(ctypes.CDLL(os.path.join(_pluginpath, _name)))
        except OSError:
            pass
osr.SetPROJSearchPaths([os.path.join(_localpath, "proj")])
gdal.SetConfigOption("GDAL_DATA", os.path.join(_localpath, "gdal"))
os.environ.setdefault("CPL_LOG", os.devnull)

_libsdir = os.path.join(os.path.dirname(_localpath), "gdal.libs")
if not os.path.exists(_libsdir):
    _libsdir = os.path.join(os.path.dirname(_localpath), "GDAL.libs")
_libs = {}
if os.path.exists(_libsdir):
    # (DLLs only: the bundled tools live here too, and gdal.exe would
    # otherwise take the "gdal" key from gdal-<hash>.dll.)
    _libs = {
        re.split(r"-|\.", name)[0]: os.path.join(_libsdir, name)
        for name in os.listdir(_libsdir) if name.lower().endswith(".dll")
    }
GDAL_LIBRARY_PATH = _libs.get("libgdal") or _libs.get("gdal", "")
GEOS_LIBRARY_PATH = _libs.get("libgeos_c") or _libs.get("geos_c", "")

# On Windows gdal.dll tears itself down when it is unloaded, after the
# interpreter is gone, and with CPL_DEBUG set it reports through whatever
# error handler is installed; a Python callback (django's) is a dead
# pointer by then and the process dies on exit.  Restore the built-in
# handler first.
import atexit
atexit.register(gdal.SetErrorHandler, "CPLDefaultErrorHandler")


# making the osgeo package version the same as the gdal version:
from sys import platform, version_info
if version_info >= (3, 8, 0) and platform == 'win32':
    import os
    if 'USE_PATH_FOR_GDAL_PYTHON' in os.environ and 'PATH' in os.environ:
        for p in os.environ['PATH'].split(';'):
            if p:
                try:
                    os.add_dll_directory(p)
                except (FileNotFoundError, OSError):
                    continue
    elif 'PATH' in os.environ:
        import glob
        for p in os.environ['PATH'].split(';'):
            try:
                if glob.glob(os.path.join(p, 'gdal*.dll')) or glob.glob(os.path.join(p, 'libgdal*.dll')):
                    os.add_dll_directory(p)
                    break
            except (FileNotFoundError, OSError):
                continue


def swig_import_helper():
    import importlib
    from os.path import dirname, basename
    mname = basename(dirname(__file__)) + '._gdal'
    try:
        return importlib.import_module(mname)
    except ImportError:
        return importlib.import_module('_gdal')


_gdal = swig_import_helper()
del swig_import_helper

__version__ = _gdal.__version__ = _gdal.VersionInfo("RELEASE_NAME")

gdal_version = tuple(int(s) for s in str(__version__).split('.') if s.isdigit())[:3]
python_version = tuple(version_info)[:3]

# Setting this flag to True will cause importing osgeo to fail on an unsupported Python version.
# Otherwise a deprecation warning will be issued instead.
# Importing osgeo from an unsupported Python version might still partially work
# because the core of GDAL Python bindings might still support an older Python version.
# Hence the default option to just issue a warning.
# To get complete functionality upgrading to the minimum supported version is needed.
fail_on_unsupported_version = False

# The following is a Sequence of tuples in the form of (gdal_version, python_version).
# Each line represents the minimum supported Python version of a given GDAL version.
# Introducing a new line for the next GDAL version will trigger a deprecation warning
# when importing osgeo from a Python version which will not be
# supported in the next version of GDAL.
gdal_version_and_min_supported_python_version = (
    ((0, 0), (0, 0)),
    ((1, 0), (2, 0)),
    ((2, 0), (2, 7)),
    ((3, 3), (3, 6)),
    # ((3, 4), (3, 7)),
    # ((3, 5), (3, 8)),
)


def ver_str(ver):
    return '.'.join(str(v) for v in ver) if ver is not None else None


minimum_supported_python_version_for_this_gdal_version = None
this_python_version_will_be_deprecated_in_gdal_version = None
last_gdal_version_to_supported_your_python_version = None
next_version_of_gdal_will_use_python_version = None
for gdal_ver, py_ver in gdal_version_and_min_supported_python_version:
    if gdal_version >= gdal_ver:
        minimum_supported_python_version_for_this_gdal_version = py_ver
    if python_version >= py_ver:
        last_gdal_version_to_supported_your_python_version = gdal_ver
    if not this_python_version_will_be_deprecated_in_gdal_version:
        if python_version < py_ver:
            this_python_version_will_be_deprecated_in_gdal_version = gdal_ver
            next_version_of_gdal_will_use_python_version = py_ver


if python_version < minimum_supported_python_version_for_this_gdal_version:
    msg = 'Your Python version is {}, which is no longer supported by GDAL {}. ' \
          'Please upgrade your Python version to Python >= {}, ' \
          'or use GDAL <= {}, which supports your Python version.'.\
        format(ver_str(python_version), ver_str(gdal_version),
               ver_str(minimum_supported_python_version_for_this_gdal_version),
               ver_str(last_gdal_version_to_supported_your_python_version))

    if fail_on_unsupported_version:
        raise Exception(msg)
    else:
        from warnings import warn
        warn(msg, DeprecationWarning)
elif this_python_version_will_be_deprecated_in_gdal_version:
    msg = 'You are using Python {} with GDAL {}. ' \
          'This Python version will be deprecated in GDAL {}. ' \
          'Please consider upgrading your Python version to Python >= {}, ' \
          'Which will be the minimum supported Python version of GDAL {}.'.\
        format(ver_str(python_version), ver_str(gdal_version),
               ver_str(this_python_version_will_be_deprecated_in_gdal_version),
               ver_str(next_version_of_gdal_will_use_python_version),
               ver_str(this_python_version_will_be_deprecated_in_gdal_version))

    from warnings import warn
    warn(msg, DeprecationWarning)

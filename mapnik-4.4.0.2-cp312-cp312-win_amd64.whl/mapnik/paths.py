import os

mapniklibpath = 'C:/liw_build/prefix/lib/mapnik'
inputpluginspath = 'C:/liw_build/prefix/lib\mapnik\input'
fontscollectionpath = 'C:/liw_build/prefix/lib\mapnik\fonts'
localpath = os.path.dirname(os.path.abspath( __file__ ))
mapniklibpath = os.path.join(localpath, 'mapnik.libs')
mapniklibpath = os.path.normpath(mapniklibpath)
inputpluginspath = os.path.join(localpath, 'input')
fontscollectionpath = os.path.join(localpath, 'fonts')
__all__ = [mapniklibpath,inputpluginspath,fontscollectionpath]

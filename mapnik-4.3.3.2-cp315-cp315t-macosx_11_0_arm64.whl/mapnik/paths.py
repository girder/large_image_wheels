import os

mapniklibpath = '/Users/admin/liw_macos_build/prefix/lib/mapnik'
inputpluginspath = '/Users/admin/liw_macos_build/prefix/lib/mapnik/input'
fontscollectionpath = '/Users/admin/liw_macos_build/prefix/lib/mapnik/fonts'
localpath = os.path.dirname(os.path.abspath( __file__ ))
mapniklibpath = os.path.join(localpath, 'mapnik.libs')
mapniklibpath = os.path.normpath(mapniklibpath)
inputpluginspath = os.path.join(localpath, 'input')
fontscollectionpath = os.path.join(localpath, 'fonts')
__all__ = [mapniklibpath,inputpluginspath,fontscollectionpath]

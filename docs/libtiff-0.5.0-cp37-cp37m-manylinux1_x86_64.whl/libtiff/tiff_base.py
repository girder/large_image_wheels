
class TiffBase:

    pass

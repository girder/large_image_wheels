# this is used in pyproject.toml and imported into __init__.py
__version__ = "3.2.0.8.18.7"

__all__ = ["__version__"]
